#include "soma.h"

double somar(double a, double b){
    return a + b;
}