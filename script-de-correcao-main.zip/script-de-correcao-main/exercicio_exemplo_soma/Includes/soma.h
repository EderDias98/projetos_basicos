#ifndef SOMA_H
#define SOMA_H

double somar(double a, double b);

#endif